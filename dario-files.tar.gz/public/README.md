# 📊 Dario Project Viewer

Your centralized dashboard for all project deliverables.

## Access

**Local Address:**
```
http://localhost:8080
```

Or open the `index.html` file directly in your browser.

## Structure

```
/public/
├── index.html (Dashboard - START HERE)
├── projects/
│   ├── wizdi-india/
│   │   ├── landing-page.html
│   │   └── linkedin-strategy.md
│   └── [future projects]
└── README.md (this file)
```

## How to Use

1. Open: http://localhost:8080
2. Click on any project card
3. View or download deliverables
4. Share links with others

## Adding New Projects

New projects will be added to `/public/projects/[project-name]/` and will appear in the dashboard automatically.

---

**Last Updated:** Feb 26, 2026
